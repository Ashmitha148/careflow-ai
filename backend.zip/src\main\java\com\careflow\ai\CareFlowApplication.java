package com.careflow.ai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CareFlowApplication {

    public static void main(String[] args) {
        SpringApplication.run(CareFlowApplication.class, args);
    }
}
